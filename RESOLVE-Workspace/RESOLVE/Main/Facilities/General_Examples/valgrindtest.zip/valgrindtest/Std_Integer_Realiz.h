#ifndef __STD_INTEGER_REALIZ_H
#define __STD_INTEGER_REALIZ_H

#include "Integer_Template.h"

extern Integer_Template* new_Std_Integer_Realiz_for_Integer_Template();
extern void free_Std_Integer_Realiz_for_Integer_Template(Integer_Template* toFree);

#endif