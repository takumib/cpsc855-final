#ifndef __STD_BOOLEAN_REALIZ_H
#define __STD_BOOLEAN_REALIZ_H

#include "Boolean_Template.h"

extern Boolean_Template* new_Std_Boolean_Realiz_for_Boolean_Template();
extern void free_Std_Boolean_Realiz_for_Boolean_Template(Boolean_Template* toFree);

#endif